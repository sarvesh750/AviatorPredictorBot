# Aviator Predictor Bot

#What is the Aviator Betting Game?
[JOIN TELEGRAM](https://t.me/AviatorProHackApp)
The Aviator game has taken the online casino world by storm since its inception in 2019.
Created by Scribe Gaming, Aviator has disrupted the betting and gaming space like no other game in history. 
Its popularity can be seen across the world, with over 2,000 betting and casino companies adding Aviator to their games portfolio, 
and now over 10 million players.

[Get Bot](https://t.me/AviatorProHackApp)

# How to Play
Aviator is a new kind of social multiplayer game consisting of an increasing curve that can collapse at any moment.
When the round starts, a multiplier scale starts to grow. The player must earn money before the lucky plane flies away.


[Get Bot](https://t.me/AviatorProHackApp)

### Screenshots

![image](https://github.com/AviatorBot/Aviator/assets/174831792/1cf1ea2d-0a5f-4ae1-8cc7-28f1046a3c41)


[Get Bot](https://t.me/AviatorProHackApp)
